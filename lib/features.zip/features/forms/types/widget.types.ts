import { type FieldApi } from '@tanstack/react-form'
import type { FormFieldConfig } from './form.types'

export interface WidgetProps {
  field: FieldApi<any, any, any, any>
  config: FormFieldConfig
}

export interface WidgetContextValue {
  // Common widget functionality
  registerField: (name: string, field: FieldApi<any, any, any, any>) => void
  unregisterField: (name: string) => void
  getField: (name: string) => FieldApi<any, any, any, any> | undefined
  showFieldError: (name: string) => boolean
  getFieldError: (name: string) => string | undefined
}

export type WidgetComponent = React.FC<WidgetProps>

export interface WidgetRegistryItem {
  component: WidgetComponent
  defaultValidation?: Array<{
    type: string
    message: string
    validate: (value: any) => boolean | Promise<boolean>
  }>
}

export type WidgetRegistry = Record<string, WidgetRegistryItem>
