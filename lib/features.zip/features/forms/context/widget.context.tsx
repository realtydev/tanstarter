import { createContext, useContext, useCallback, useMemo } from "react";
import type { FieldApi } from "@tanstack/react-form";
import type { WidgetContextValue } from "../types/widget.types";

const WidgetContext = createContext<WidgetContextValue | null>(null);

export function useWidget() {
  const context = useContext(WidgetContext);
  if (!context) {
    throw new Error("useWidget must be used within a WidgetProvider");
  }
  return context;
}

interface WidgetProviderProps {
  children: React.ReactNode;
}

export function WidgetProvider({ children }: WidgetProviderProps) {
  // Store field references
  const fields = useMemo(() => new Map<string, FieldApi<any, any, any, any>>(), []);

  const registerField = useCallback(
    (name: string, field: FieldApi<any, any, any, any>) => {
      fields.set(name, field);
    },
    [fields],
  );

  const unregisterField = useCallback(
    (name: string) => {
      fields.delete(name);
    },
    [fields],
  );

  const getField = useCallback(
    (name: string) => {
      return fields.get(name);
    },
    [fields],
  );

  const showFieldError = useCallback(
    (name: string) => {
      const field = fields.get(name);
      return Boolean(field?.state.meta.isTouched && field?.state.meta.errors.length);
    },
    [fields],
  );

  const getFieldError = useCallback(
    (name: string): string | undefined => {
      const field = fields.get(name);
      const error = field?.state.meta.errors[0];
      return typeof error === "string" ? error : undefined;
    },
    [fields],
  );

  const value = useMemo(
    () => ({
      registerField,
      unregisterField,
      getField,
      showFieldError,
      getFieldError,
    }),
    [registerField, unregisterField, getField, showFieldError, getFieldError],
  );

  return <WidgetContext.Provider value={value}>{children}</WidgetContext.Provider>;
}
