import { describe, it, expect, vi } from "vitest";
import { renderHook, act } from "@testing-library/react";
import { WidgetProvider, useWidget } from "../widget.context";

describe("Widget Context", () => {
  it("registers and unregisters fields", () => {
    const wrapper = ({ children }: { children: React.ReactNode }) => (
      <WidgetProvider>{children}</WidgetProvider>
    );

    const { result } = renderHook(() => useWidget(), { wrapper });

    const mockField = {
      state: {
        meta: {
          isTouched: false,
          errors: [],
        },
      },
    } as any;

    act(() => {
      result.current.registerField("test", mockField);
    });

    expect(result.current.getField("test")).toBe(mockField);

    act(() => {
      result.current.unregisterField("test");
    });

    expect(result.current.getField("test")).toBeUndefined();
  });

  it("shows field errors correctly", () => {
    const wrapper = ({ children }: { children: React.ReactNode }) => (
      <WidgetProvider>{children}</WidgetProvider>
    );

    const { result } = renderHook(() => useWidget(), { wrapper });

    const mockField = {
      state: {
        meta: {
          isTouched: true,
          errors: ["Required field"],
        },
      },
    } as any;

    act(() => {
      result.current.registerField("test", mockField);
    });

    expect(result.current.showFieldError("test")).toBe(true);
    expect(result.current.getFieldError("test")).toBe("Required field");
  });

  it("throws error when used outside provider", () => {
    const { result } = renderHook(() => useWidget());
    expect(result.error).toEqual(Error("useWidget must be used within a WidgetProvider"));
  });
});
