import type { WidgetRegistry } from '../types/widget.types'

const registry: WidgetRegistry = new Map()

export function registerWidget(type: string, component: React.FC<any>, defaultValidation?: any[]) {
  registry.set(type, { component, defaultValidation })
}

export function getWidget(type: string) {
  return registry.get(type)
}

export function hasWidget(type: string) {
  return registry.has(type)
}

// Export registry for testing
export const __registry = registry
